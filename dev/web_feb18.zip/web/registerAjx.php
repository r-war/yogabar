<?php
session_start();
$curSessionId=md5(session_id().time());
//include realpath(__DIR__ . '/..')."/configs/config.php";
require_once(realpath(__DIR__ . '/..')."/configs/phpmailer/class.phpmailer.php");
require_once realpath(__DIR__ . '/..')."/configs/phpmailer/PHPMailerAutoload.php";
require_once(realpath(__DIR__ . '/..')."/configs/db/Db.class.php");
$mode=$_POST['mode'];
$db = new Db();
        
if($mode=="addReg")
{

$uname=trim($_POST['uname']);  
$uemail=trim($_POST['uemail']) ;
$password=trim($_POST['password']);


if(strlen($_SESSION['key']) && $_POST['captcha1'] == $_SESSION['key'])
    {
         
    }
    else
    {
        echo 4;
        exit;
    }
 
$ChkExist=$db->query("SELECT count(user_id) AS UCnt, user_id,user_name,password,email,session_id,mobile_no,created_at,updated_at,active,blocked FROM user_registration WHERE email=:email",array("email"=>"$uemail"));

$Ucnt=$ChkExist[0]['UCnt'];
$Ndt=date('Y-m-d H:i:s');
if($Ucnt==0)
{

	

	 
	$to=trim($_POST['uemail']);
	$from_name='Yogabar';
	$subject='Account Activation mail from Yogabar';

$message= '
<style>
 
body {
    padding: 0;
    margin: 0;
}

html { -webkit-text-size-adjust:none; -ms-text-size-adjust: none;}
@media only screen and (max-device-width: 680px), only screen and (max-width: 680px) { 
    *[class="table_width_100"] {
		width: 96% !important;
	}
	*[class="border-right_mob"] {
		border-right: 1px solid #dddddd;
	}
	*[class="mob_100"] {
		width: 100% !important;
	}
	*[class="mob_center"] {
		text-align: center !important;
	}
	*[class="mob_center_bl"] {
		float: none !important;
		display: block !important;
		margin: 0px auto;
	}	
	.iage_footer a {
		text-decoration: none;
		color: #929ca8;
	}
	img.mob_display_none {
		width: 0px !important;
		height: 0px !important;
		display: none !important;
	}
	img.mob_width_50 {
		width: 40% !important;
		height: auto !important;
	}
}
.table_width_100 {
	width: 680px;
}
</style>



<div id="mailsub" class="notification" align="center">

<table width="100%" border="0" cellspacing="0" cellpadding="0" style="min-width: 320px;"><tr><td align="center" bgcolor="#eff3f8" style="padding:30px;">
<table border="0" cellspacing="0" cellpadding="0" class="table_width_100" width="100%" style="max-width: 680px; min-width: 300px;">
    <tr><td>
	 
	</td></tr>
	 
	<tr><td align="center" bgcolor="#ffffff">
		 <div style="height: 30px; line-height: 30px; font-size: 10px;"></div>
		<table width="90%" border="0" cellspacing="0" cellpadding="0">
			<tr><td align="center">
			    		<a href="#" target="_blank" style="color: #596167; font-family: Arial, Helvetica, sans-serif; float:left; width:100%; padding:20px;text-align:center; font-size: 13px;">
									<font face="Arial, Helvetica, sans-seri; font-size: 13px;" size="3" color="#596167">
									<img src="http://yogabar.sg/web/images/img_logo.png" width="120" alt="Yogabar" border="0"  /></font></a>
					</td>
					<td align="right">
				 <div style="height: 50px; line-height: 50px; font-size: 10px;"></div>
	</td></tr>
	 
	<tr><td align="center" bgcolor="#fbfcfd">
		<table width="90%" border="0" cellspacing="0" cellpadding="0">
			<tr><td align="center">
				 <div style="height: 60px; line-height: 60px; font-size: 10px;"></div>
				<div style="line-height: 44px;">
					<font face="Arial, Helvetica, sans-serif" size="5" color="#57697e" style="font-size: 34px;">
					<span style="font-family: Arial, Helvetica, sans-serif; font-size: 34px; color: #57697e;">
						<span style="color:#37cf87;" >Hello, </span>'.$uname.'
					</span></font>
				</div>
				 <div style="height: 40px; line-height: 40px; font-size: 10px;"></div>
			</td></tr>
			<tr><td align="center">
				<div style="line-height: 24px;">
					<font face="Arial, Helvetica, sans-serif" size="4" color="#57697e" style="font-size: 15px;">
					<span style="font-family: Arial, Helvetica, sans-serif; font-size: 15px; color: #57697e;">
						Thank you very much for registering your profile with Yogabar. Click the following button to complete the Registration Process in Yogabar.
					</span></font>
				</div> 
				 <div style="height: 40px; line-height: 40px; font-size: 10px;"></div>
			</td></tr>
			<tr><td align="center">
				<div style="line-height: 24px;">
					<a style="width:200px; padding: 15px;  font-size:18px;cursor: pointer; box-shadow:none; color: #fff; border-color: #37CF87; background-color: #37CF87; border-radius: 2px;text-decoration:none " href="http://dev.yogabar.sg/web/active_register.php?sid='.$curSessionId.'" target="_blank" class="btn btn-danger block-center">
					    Activate Now
					</a>
				</div>
				 <div style="height: 60px; line-height: 60px; font-size: 10px;"></div>
			</td></tr>
		</table>		
	</td></tr>
	 
	<tr><td class="iage_footer" align="center" bgcolor="#ffffff">

		
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr><td align="center" style="padding:20px;flaot:left;width:100%; text-align:center;">
				<font face="Arial, Helvetica, sans-serif" size="3" color="#96a5b5" style="font-size: 13px;">
				<span style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #96a5b5;">
					2017 © Yogabar. ALL Rights Reserved.
				</span></font>				
			</td></tr>			
		</table>
		

	</td></tr>
	 
	<tr><td>

	</td></tr>
</table>
</td></tr>
</table>
</div>';


	/*$message="<table><tr><td>Dear $uname,</td></tr> <tr><td>Thank you very much for registering your profile with Yogabar </td></tr><tr><td> Click the following link to complete the Registration Process in Yogabar</td></tr>
	<tr><td><a href='http://yogabar.sg/web/active_register.php?sid=$curSessionId'>Click here  </td> </tr> 
	</table>";*/


 $messageddd='<html><body><head><title>Yogabar</title><meta http-equiv="Content-Type" content="text/html; charset=utf-8">  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"><link href="http://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet" type="text/css">   <link href="http://yogabar.sg/web/css/mailTemp.css" rel="stylesheet" type="text/css">

  </head>
  <body style="margin: 0; padding: 0;" yahoo="fix">

    <div class="main_container" style="box-shadow: 0 0 5px #000;">
      
      
      <table class="in_container" border="0" cellpadding="0" cellspacing="0" width="100%" align="center" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;">
        <tr>
          <td>
            
            <table border="0" cellpadding="0" cellspacing="0"  width="100%" height="100px" align="center" background="http://ryanhallmedia.com/thirdspace/img/email/topback.jpg" bgcolor="3d424e" style="background-image:url("img/topback.jpg"); background-size: cover; -webkit-background-size: cover; -moz-background-size: cover -o-background-size: cover; background-position: bottom center; background-repeat: no-repeat; background-color:#3d424e;border-radius:2px 2px 0px 0px;-webkit-filter: invert(100%);">
               
         
            
                <td align="center">
                  
                  <table width="200" cellpadding="0" cellspacing="0" align="center" height="100px" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; background: #37cf87; border-radius:2px;display:none" class="center">
                    <td>
                      <tr>
                        <a href="#">
                          <img src="http://yogabar.sg/web/images/img_logo.png" style="-webkit-filter: invert(100%);">
                        </a>
                      </tr>
                    </td>
                  </table>
                  
                </td>
              </tr>
              <tr><td height="15" width="100%" style="height:35px;"></td></tr>
            </table>
            
            <table border="0" cellpadding="0" cellspacing="0" width="100%" align="center" bgcolor="ffffff" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; background-color:#ffffff;">
              <tr><td height="65px" width="100%" style="height:65px;"></td></tr>
              <tr>
                <td align="center">
                  <table class="full_width_600" width="600" border="0" cellpadding="0" cellspacing="0" align="center" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; border:0;text-align:center;">
                    <tr>
                      <td>
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; border:0;">
                          <tr>
                            <td align="right" width="46%" style="width:46%; text-align:right; color: #37cf87; font-family: "Open Sans", Helvetica, Arial, sans-serif; font-size: 25px; font-weight: 600; line-height:30px;"><font color="#37cf87">Hello,</font></td>
                            <td align="left" width="54%" style="width:54%; text-align:left; color: #676f84; font-family: "Open Sans", Helvetica, Arial, sans-serif; font-size: 25px; font-weight: 600; line-height:30px;">&nbsp;'.$uname.'</td>
                          </tr>
                        </table>
                      </td>
                    </tr> 
                    <tr><td height="15px" width="100%" style="height:15px;"></td></tr>
                    <tr>
                      <td>
                        <table width="100%" border="0" height="100px" cellpadding="0" cellspacing="0" style="max-width: 400px; margin:0 auto;border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; border:0;">
                          <tr>
                            <td style="text-align:center; color: #666; font-family: "Open Sans", Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 600; line-height: 20px;">
                              Thank you very much for registering your profile with Yogabar. Click the following button to complete the Registration Process in Yogabar.
                            </td>
                          </tr>
                           <tr>
                            <td align="center" style="text-align:center;">
                               
                            </td>
                          </tr>
                        </table>
                      </td>
                    </tr>

                    <tr>
                      <td style="text-align: center;float: left;padding: 40px 0 0;text-align: center;  width: 100%; ">
                         
          <a href="http://yogabar.sg/web/active_register.php?sid='.$curSessionId.'" style="width:200px; padding: 15px;  font-size:18px;
                          cursor: pointer; box-shadow:none; color: #fff; border-color: #37CF87; background-color: #37CF87; border-radius: 2px;text-decoration:none " >Activate Now </a>
                   
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>


              <tr><td height="65px" width="100%" style="height:65px;"></td></tr>

            </table>
        
            
           

  </body>
</html>'; 
	 
        $subject="Account Activation mail from Yogabar";
        $headers = "From:yogabar@systimanx.com \r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html\r\n";
        $SendMail=mail($to, $subject, $message, $headers);

 
         if($SendMail==1)
          {
   
        
        $MdpassW=md5($_POST['password']);
	  $ChkInsert=$db->query("INSERT INTO user_registration(user_name,email,password,session_id,created_at)
	VALUES(:user_name,:email,:password,:session_id,:created_at)",array("user_name"=>"$uname","email"=>"$uemail","password"=>"$MdpassW","session_id"=>"$curSessionId","created_at"=>"$Ndt")); 
            echo 1;

          }
          else
          {

           echo 2;

          }
	 

   
     
}
else
{

 echo 0;
}

}



?>



 
